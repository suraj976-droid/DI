﻿using DI.Models;

namespace DI.Repository
{
    public interface IProduct
    {
        public List<Product> FetchProduct();
        public void AddProduct(Product p);
    }
}
