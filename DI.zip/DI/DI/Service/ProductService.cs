﻿using DI.Data;
using DI.Models;
using DI.Repository;

namespace DI.Service
{
    public class ProductService : IProduct
    {
        private readonly ApplicationDbContext db;

        public ProductService(ApplicationDbContext db)
        {
            this.db = db;
        }
        public void AddProduct(Product p)
        {
           db.Products.Add(p);
           db.SaveChanges();
        }

        public List<Product> FetchProduct()
        {
            var data = db.Products.ToList();
            return data;
        }

    }
}
